# 人工智能导论cv实验报告

#### 														黄志鹏 PB16150288

## 1. 实验内容

## 2. 实验结果

## 3. 实验分析

### 3.1 实验原理

- 利用下图的几何分析可以知道, p点深度z 和xl - xr 成反比

![image](/home/huangzp/code/cv/disparity/jihe.png)

​	反比公式如下:

![image](/home/huangzp/code/cv/disparity/gongshi.png)

- 寻找每个pixel的对应pixel, 然后x轴距离相减, 就可以得到xr - xl 的值  





  ![image](/home/huangzp/code/cv/disparity/gongshi2.png)



  ### 3.2 实验结果分析




