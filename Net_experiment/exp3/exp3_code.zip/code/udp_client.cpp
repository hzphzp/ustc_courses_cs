#include<sys/types.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
using namespace std;

#define ADDR "127.0.0.1" //在本机测试用这个地址，如果连接其他电脑需要更换IP
#define SLEEP 1
#define TIMES 10
#define PORT 1234
#define MAXSIZE 1024
int main(){
    char buf[MAXSIZE];
    FILE * client_buf_file = fopen("udp_client_data", "rb");
    if(!client_buf_file){
        fprintf(stderr, "cannot open the udp client buf file!\n");
        exit(1);
    }
    struct sockaddr_in server_addr, client_addr;
    memset((void *) &server_addr, 0, sizeof(server_addr));
    memset((void *) &client_addr, 0, sizeof(client_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(ADDR);
    server_addr.sin_port = htons(PORT);
    int server_fd;
    if((server_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
        fprintf(stderr, "apply the socket error!\n");
        exit(1);
    }
    for (int i = 0; i < TIMES; i ++){
        fread(buf, sizeof(char), MAXSIZE, client_buf_file);
        cout << buf << endl;
        //while(sendto(server_fd, (void *) &buf, sizeof(char), MAXSIZE, (sockaddr *) &server_addr, sizeof(server_addr)) != MAXSIZE);
        sendto(server_fd, buf, MAXSIZE, 0, (sockaddr *) &server_addr, sizeof(server_addr));
        sleep(SLEEP);
    }
    close(server_fd);
    return 0;
}