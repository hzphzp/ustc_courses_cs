#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
using namespace std;

#define PORT 8088

int main(){
    char buf[1024]; //store the data received from the client 
    char message[1024];//the data to be sent
    socklen_t len; //to store the len of client_in (address)'s length
    struct sockaddr_in server_in, client_in;
    int server_fd, client_fd;
    //fill the void pointer
    memset((void *) &server_in, 0, sizeof(sockaddr_in));
    memset((void *) &client_in, 0, sizeof(sockaddr_in));
    //set server_in(address)
    server_in.sin_family = AF_INET; //IPV4 communication domain
    server_in.sin_port = htons(PORT); //accept any address
    server_in.sin_addr.s_addr = INADDR_ANY;

    //set assign the socket of the server
    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    //bind the socket with the fd
    if(bind(server_fd, (struct sockaddr*) &server_in, sizeof(server_in)) < 0) {
        fprintf(stderr, "bind error!\n");
        exit(1);
    }
    //listen to the port 
    if(listen(server_fd, 5) < 0) {
        fprintf(stderr, "listen error!\n");
        exit(1);
    }
    cout << "begin" << endl;

    //accept the requst
    client_fd = accept(server_fd, (struct sockaddr*) &client_fd, &len);
    //if connected
    cout << "connected with" << client_in.sin_addr.s_addr << "::" << client_in.sin_port << endl;
    while(client_fd >= 0){
        while(read(client_fd, buf, 1024) != 1024);
        if(!strcmp(buf, "q\n")) {
            //client close
            cout << "client close!" << endl;
            close(client_fd);
            client_fd = -1; //to loop out of this connection
            break;
        }    
        cout << buf ;
        cout << ">>>";
        fgets(message, 1024, stdin); 
        while(write(client_fd, (void *)message, 1024*sizeof(char)) != 1024){
            cout << ">>>";
            fgets(message, 1024, stdin); 
        }
        if(!strcmp(message, "q\n")){
            //server close
            cout << "server close!" << endl;
            close(client_fd);
            client_fd = -1;
            break;
        }
    }
    close(server_fd);
    return 0;
}

