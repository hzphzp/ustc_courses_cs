#include <sys/types.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
using namespace std;

#define PORT 1234
#define MAXSIZE 1024
#define TIMES 10
int main(){
    FILE* server_buf_file = fopen("udp_server_data", "wb");
    if(!server_buf_file){
        fprintf(stderr, "cannot open the server buf file!\n");
        exit(1);
    }
    int count = 0;
    socklen_t len; //to store the length of the client address
    char buf[MAXSIZE];
    struct sockaddr_in server_addr, client_addr;
    memset((void *) &server_addr, 0, sizeof(server_addr));
    memset((void *) &client_addr, 0, sizeof(client_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(PORT);
    server_addr.sin_addr.s_addr= htonl (INADDR_ANY);
    int server_fd;
    //apply the udp socket
    server_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if((bind(server_fd, (sockaddr *) &server_addr, sizeof(server_addr))) < 0){
        fprintf(stderr, "bind error!\n");
        exit(1);
    }
    for(int i = 0; i < TIMES; i++){
        if(recvfrom(server_fd, (void *) buf, MAXSIZE*sizeof(char), 0, (sockaddr *) &client_addr, (socklen_t *) &len) == -1){
            //drop the data packet
            fprintf(stderr, "drop the packet!\n");
            count ++;
        }
        else{
            fprintf(stderr, "receive the packet!\n");
        }
        if(fwrite((void *) buf, sizeof(char), MAXSIZE, server_buf_file) != MAXSIZE){
            fprintf(stderr, "write the buf wrong!\n");
        }
    }
    cout << "drop " << count << " packets" << endl;
    close(server_fd);
    return 0;
}