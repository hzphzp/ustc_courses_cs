#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#define BUF_SIZE 100
#define ADDR "127.0.0.1" //在本机测试用这个地址，如果连接其他电脑需要更换IP
#define SERVERPORT 8088
using namespace std;

int main(){
    int server_fd;
    char buf[1024];
    char message[1024];
    if((server_fd = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
        fprintf(stderr, "socket apl error!\n");
        exit(1);
    }
    struct sockaddr_in server_addr;
    memset((void *) &server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(ADDR);
    server_addr.sin_port = htons(SERVERPORT);
    if(connect(server_fd, (sockaddr *) &server_addr, sizeof(sockaddr)) < 0){
        fprintf(stderr, "socket connected error!");
        exit(1);
    }
    else{
        cout << "connected to " << server_addr.sin_addr.s_addr << "::" << server_addr.sin_port << endl;
    }
    while(1){
        cout << ">>>";
        fgets(message, 1024, stdin); 
        while(write(server_fd, (void *) &message, 1024*sizeof(char)) != 1024){
            cout << ">>>";
            fgets(message, 1024, stdin); 
        }
        if(!strcmp(message, "q\n")){
            //close the connection
            cout << "the client close the talk" << endl;
            close(server_fd);
            break;
        }
        while(read(server_fd, (void *) &buf, 1024*sizeof(char)) != 1024);
        if(!strcmp(buf, "q\n")){
            //close the connection
            cout << "the server close the talk" << endl;
            close(server_fd);
            break;
        }
        cout << buf;
    }
}